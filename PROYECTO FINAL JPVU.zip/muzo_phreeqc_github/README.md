# Modelamiento Geoquímico — Distrito de Muzo, Colombia

Simulación del equilibrio geoquímico del sistema hidrotermal formador de esmeraldas del
Distrito de Muzo (Colombia) con **PHREEQC v3** y **Python 3**.

**Autor:** Juan Pablo Vélez Uribe  
**Curso:** Modelamiento Computacional de Procesos Geoquímicos  
**Fecha:** Mayo 2026

---

## Descripción

Las esmeraldas colombianas del Cinturón Esmeraldífero Occidental (CEO) se forman por la
interacción de salmueras hidrotermales (>22 wt% NaCl eq., 280–330 °C) con secuencias de
evaporitas y lutitas negras del Cretácico. Este proyecto simula cuatro escenarios:

| Modelo | Descripción |
|--------|-------------|
| **M1** | Equilibrio mineral a T=300 °C, P=1 000 bar |
| **M2** | Enfriamiento 300 → 150 °C (pasos de 10 °C) |
| **M3** | Mezcla fluido hidrotermal + agua meteórica (0 – 90 %) |
| **M4** | Control del pH sobre la especiación de Be²⁺ (pH 4–9, T=200 °C) |

---

## Estructura

```
muzo_phreeqc/
├── README.md
├── requirements.txt
├── .gitignore
├── scripts/
│   ├── phreeqc_muzo.py          # Script principal — ejecuta los 4 modelos
│   └── figures.py               # Genera las 2 figuras del informe
├── data/
│   └── muzo_modelos.phrq        # Scripts PHREEQC nativos (GUI / CLI)
├── results/                     # Generado por phreeqc_muzo.py
│   └── phreeqc_results.json
└── figures/                     # Generado por figures.py
    ├── figA_enfriamiento_mezcla.png
    └── figB_pH_Be.png
```

---

## Instalación

```bash
pip install -r requirements.txt
```

## Uso

```bash
# 1. Ejecutar los modelos PHREEQC (genera results/phreeqc_results.json)
python scripts/phreeqc_muzo.py

# 2. Generar las figuras (genera figures/figA_*.png y figB_*.png)
python scripts/figures.py

# 3. (Opcional) Correr los scripts nativos PHREEQC desde la GUI o CLI
phreeqc data/muzo_modelos.phrq data/muzo_modelos.out /ruta/a/llnl.dat
```

---

## Base de datos termodinámica

**llnl.dat** (Lawrence Livermore National Laboratory), incluida en el paquete `phreeqc`
de PyPI. Válida 0–300 °C. Contiene datos para Be, Al, Fe, S, Ca, Na, Mg, K, Si, C y los
minerales Anhydrite, Calcite, Dolomite, Pyrite, Halite, Quartz, Bromellite (BeO).

> Beryl (Be₃Al₂Si₆O₁₈) **no figura** en llnl.dat. Se usa Bromellite (BeO) como proxy
> para evaluar tendencias de estabilidad del Be.

Los coeficientes de actividad se calculan con el modelo **B-dot** (Debye-Hückel
extendido), válido hasta I ≈ 2–3 mol/kgw. La fuerza iónica del fluido de Muzo
(I ≈ 2.52 mol/kgw) se aproxima a ese límite.

---

## Resultados principales

- **Pirita** estable desde ~280 °C → mineral temprano (coherente con paragénesis observada)  
- **Calcita** alcanza equilibrio a ~240 °C → transición de especiación del CO₃²⁻  
- **Anhidrita** estable < 220 °C → solubilidad retrógrada (ΔHr < 0 para disolución)  
- La **mezcla** con agua meteórica reduce log m(Be²⁺) en **7 órdenes de magnitud**
  (de −9.71 a −16.67), siendo las zonas de mezcla los sitios privilegiados de precipitación del berilo  
- El **pH** controla la especiación: Be²⁺ domina en pH < 5.8 (transporte óptimo);
  BeO₂²⁻ domina en pH > 6.0 (precipitación forzada, −4 unidades log m por unidad de pH)

---

## Referencias

- Giuliani, G. et al. (2000). *Sulfate reduction by organic matter in Colombian emerald deposits.* Economic Geology, 95(5), 987–1006.
- Ottaway, T. L. et al. (1994). *Formation of the Muzo hydrothermal emerald deposit.* Nature, 369, 552–554.
- Parkhurst, D. L. & Appelo, C. A. J. (2013). *PHREEQC version 3.* USGS TM 6-A43.
- Groat, L. A. et al. (2008). *Emerald deposits and occurrences.* Ore Geology Reviews, 34, 87–112.
- Appelo, C. A. J. & Postma, D. (2005). *Geochemistry, Groundwater and Pollution* (2ª ed.). Balkema, 649 pp.
