"""
phreeqc_muzo.py
===============
Modelamiento geoquímico de fluidos hidrotermales asociados a la mineralización
de esmeraldas en el Distrito de Muzo, Colombia.

Autor  : Juan Pablo Vélez Uribe
Curso  : Modelamiento Computacional de Procesos Geoquímicos
Fecha  : Mayo 2026

Descripción
-----------
Ejecuta cuatro modelos con IPhreeqc (phreeqpy) y la base de datos llnl.dat:
    1. Equilibrio mineral a T=300 °C, P=1000 bar
    2. Enfriamiento 300→150 °C (pasos de 10 °C)
    3. Mezcla fluido hidrotermal + agua meteórica (0–100 %)
    4. Control del pH sobre la especiación de Be²⁺ (pH 4–9, T=200 °C)

Dependencias
------------
    pip install phreeqpy numpy matplotlib pandas
    pip install phreeqc   # provee llnl.dat

Uso
---
    python phreeqc_muzo.py

Referencias
-----------
    Giuliani et al. (2000) Econ. Geol. 95:987-1006
    Ottaway et al.  (1994) Nature 369:552-554
    Parkhurst & Appelo (2013) USGS TM 6-A43
"""

import json
import numpy as np
from pathlib import Path
from phreeqpy.iphreeqc.phreeqc_dll import IPhreeqc

# ── Rutas ──────────────────────────────────────────────────────────────────
import phreeqc as _phreeqc_pkg
LLNL_DAT = str(Path(_phreeqc_pkg.__file__).parent / "databases" / "llnl.dat")
RESULTS_FILE = Path("results") / "phreeqc_results.json"
RESULTS_FILE.parent.mkdir(exist_ok=True)

# ── Composición de fluidos ─────────────────────────────────────────────────
# Fluido hidrotermal - Muzo (Giuliani et al. 2000; Ottaway et al. 1994)
# T_homog = 280-330 °C  |  Salinidad >22 wt% NaCl eq.  |  pH ~5.5  |  pe ~-5
HYD = dict(
    temp=300, pressure=1000, pH=5.5, pe=-5,
    units="mmol/L", density=1.15,
    Na=3800, Ca=850, K=220, Mg=45,
    Cl=5300, S6=28, S2=2.5, C=12,
    Si=8.5, Al=0.18, Fe=3.2, Be=0.22,
)

# Agua meteórica diluta (referencia Cordillera Oriental colombiana)
MET = dict(
    temp=25, pressure=1, pH=6.8, pe=4,
    units="mmol/L", density=1.00,
    Na=0.35, Ca=0.80, K=0.08, Mg=0.25,
    Cl=0.40, S6=0.10, C=1.5, Si=0.30,
)

MINERALS = ["Anhydrite", "Calcite", "Dolomite", "Pyrite", "Halite", "Quartz"]


# ── Helpers ────────────────────────────────────────────────────────────────
def make_solution(n: int, f: dict, label: str = "") -> str:
    """Genera un bloque SOLUTION para PHREEQC."""
    lines = [
        f"SOLUTION {n}  {label}",
        f"    temp        {f['temp']}",
        f"    pressure    {f.get('pressure', 1)}",
        f"    pH          {f['pH']}",
        f"    pe          {f['pe']}",
        f"    units       {f['units']}",
        f"    density     {f.get('density', 1.0)}",
        f"    Na          {f['Na']}",
        f"    Ca          {f['Ca']}",
        f"    K           {f['K']}",
        f"    Mg          {f['Mg']}",
        f"    Cl          {f['Cl']}",
        f"    S(6)        {f['S6']}",
    ]
    if "S2" in f:
        lines.append(f"    S(-2)       {f['S2']}")
    lines += [
        f"    C           {f['C']}",
        f"    Si          {f['Si']}",
    ]
    if "Al" in f:
        lines.append(f"    Al          {f['Al']}")
    if "Fe" in f:
        lines.append(f"    Fe          {f['Fe']}")
    if "Be" in f:
        lines.append(f"    Be          {f['Be']}")
    lines.append("    -water      1")
    return "\n".join(lines)


EQ_PHASES = """
EQUILIBRIUM_PHASES 1
    Anhydrite   0   0
    Calcite     0   0
    Dolomite    0   0
    Pyrite      0   0
    Halite      0   0
    Quartz      0   0
"""

SI_LIST = " ".join(MINERALS + ["Bromellite"])

SELECTED = f"""
SELECTED_OUTPUT
    -reset      false
    -pH         true
    -pe         true
    -temperature true
    -ionic_strength true
    -molalities Be+2 BeO2-2
    -saturation_indices {SI_LIST}
"""


def run_phreeqc(input_str: str) -> list[dict]:
    """Ejecuta PHREEQC y retorna filas de SELECTED_OUTPUT como lista de dicts."""
    p = IPhreeqc()
    p.load_database(LLNL_DAT)
    p.run_string(input_str)
    err = p.get_error_string()
    if err.strip():
        errs = [l for l in err.split("\n") if l.strip() and "WARNING" not in l]
        if errs:
            print("  [PHREEQC]:", errs[0][:120])
    arr = p.get_selected_output_array()
    if len(arr) < 2:
        return []
    headers = arr[0]
    return [dict(zip(headers, row)) for row in arr[1:]]


# ── MODELO 1: Equilibrio a 300 °C ─────────────────────────────────────────
def modelo1() -> dict:
    print("\n=== MODELO 1: Equilibrio a T=300 °C, P=1000 bar ===")
    inp = make_solution(1, HYD, "Fluido hidrotermal Muzo") + EQ_PHASES + SELECTED + "\nEND\n"
    rows = run_phreeqc(inp)
    result = {"before_eq": rows[0] if rows else {}, "after_eq": rows[1] if len(rows) > 1 else {}}
    for label, r in [("Antes", result["before_eq"]), ("Después", result["after_eq"])]:
        print(f"  {label}: pH={r.get('pH',0):.3f}  pe={r.get('pe',0):.3f}  "
              f"I={r.get('mu',0):.3f} mol/kgw")
        for m in MINERALS:
            v = r.get(f"si_{m}")
            if v is not None and abs(v) < 500:
                print(f"    {m:12s}: SI={v:+.3f}")
    return result


# ── MODELO 2: Enfriamiento 300→150 °C ─────────────────────────────────────
def modelo2() -> list[dict]:
    print("\n=== MODELO 2: Enfriamiento 300→150 °C ===")
    results = []
    for T in range(300, 140, -10):
        P = max(200, int(T * 3.3))
        fluid = dict(HYD, temp=T, pressure=P)
        inp = make_solution(1, fluid) + EQ_PHASES + SELECTED + "\nEND\n"
        rows = run_phreeqc(inp)
        if rows and len(rows) > 1:
            r = rows[1]  # post-equilibrio
            row = {"T": T, "pH": r.get("pH")}
            for m in MINERALS + ["Bromellite"]:
                row[m] = r.get(f"si_{m}")
            row["Be2_mol"] = r.get("m_Be+2(mol/kgw)")
            results.append(row)
            print(f"  T={T:3d}°C  pH={row['pH']:.2f}  "
                  f"Calcite={row['Calcite']:+.3f}  Anhydrite={row['Anhydrite']:+.3f}  "
                  f"Pyrite={row['Pyrite']:+.3f}")
    print(f"  [{len(results)} pasos completados]")
    return results


# ── MODELO 3: Mezcla 0–100 % meteórica ────────────────────────────────────
def modelo3() -> list[dict]:
    print("\n=== MODELO 3: Mezcla fluido hidrotermal + agua meteórica ===")
    results = []
    for fmet in [i / 10 for i in range(0, 11)]:
        fhyd = round(1.0 - fmet, 1)
        inp = (
            make_solution(1, HYD, "Fluido hidrotermal")
            + "\n"
            + make_solution(2, MET, "Agua meteórica")
            + f"""
MIX 1
    1   {fhyd}
    2   {fmet}

USE SOLUTION MIX 1

EQUILIBRIUM_PHASES 1
    Anhydrite   0   0
    Calcite     0   0
    Dolomite    0   0
    Pyrite      0   0
    Quartz      0   0
"""
            + SELECTED
            + "\nEND\n"
        )
        rows = run_phreeqc(inp)
        if rows:
            r = rows[-1]
            be2 = r.get("m_Be+2(mol/kgw)") or 1e-30
            row = {
                "f_met": fmet, "f_hyd": fhyd,
                "pH": r.get("pH"), "T_mix": r.get("temp(C)"),
                "IS": r.get("mu"), "Be2_mol": float(be2),
                "log_Be2": float(np.log10(be2)) if be2 > 0 else -30.0,
            }
            for m in ["Anhydrite", "Calcite", "Dolomite", "Pyrite", "Bromellite"]:
                row[m] = r.get(f"si_{m}")
            results.append(row)
            print(f"  f_met={fmet:.1f}  T~{row['T_mix']:.0f}°C  pH={row['pH']:.2f}  "
                  f"log[Be²⁺]={row['log_Be2']:.2f}  Calcite={row['Calcite']:+.3f}")
    print(f"  [{len(results)} fracciones completadas]")
    return results


# ── MODELO 4: Efecto pH sobre Be²⁺ ───────────────────────────────────────
def modelo4() -> list[dict]:
    print("\n=== MODELO 4: Efecto pH sobre Be²⁺ (T=200 °C) ===")
    results = []
    for pH_val in np.arange(4.0, 9.25, 0.25):
        fluid = dict(HYD, temp=200, pressure=500, pH=float(pH_val))
        inp = make_solution(1, fluid) + SELECTED + "\nEND\n"
        rows = run_phreeqc(inp)
        if rows:
            r = rows[0]
            be2  = r.get("m_Be+2(mol/kgw)") or 1e-30
            beo2 = r.get("m_BeO2-2(mol/kgw)") or 1e-30
            row = {
                "pH_set": float(pH_val),
                "pH_actual": r.get("pH", float(pH_val)),
                "Be2_mol": float(be2),
                "BeO2_mol": float(beo2),
                "log_Be2": float(np.log10(be2)),
                "log_BeO2": float(np.log10(beo2)),
                "SI_Bromellite": r.get("si_Bromellite"),
                "SI_Calcite": r.get("si_Calcite"),
                "SI_Anhydrite": r.get("si_Anhydrite"),
            }
            results.append(row)
            print(f"  pH={pH_val:.2f}  log[Be²⁺]={row['log_Be2']:.2f}  "
                  f"log[BeO₂²⁻]={row['log_BeO2']:.2f}  "
                  f"SI_Bromellite={row['SI_Bromellite']:.2f}")
    print(f"  [{len(results)} puntos completados]")
    return results


# ── MAIN ───────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("=" * 60)
    print("PHREEQC — Modelamiento Geoquímico Muzo, Colombia")
    print("Juan Pablo Vélez Uribe | Mayo 2026")
    print("=" * 60)

    all_results = {
        "model1": modelo1(),
        "model2_cooling": modelo2(),
        "model3_mixing": modelo3(),
        "model4_pH": modelo4(),
    }

    with open(RESULTS_FILE, "w", encoding="utf-8") as f:
        json.dump(all_results, f, indent=2, default=str)

    print("\n" + "=" * 60)
    print(f"Resultados guardados en: {RESULTS_FILE}")
    print("=" * 60)
