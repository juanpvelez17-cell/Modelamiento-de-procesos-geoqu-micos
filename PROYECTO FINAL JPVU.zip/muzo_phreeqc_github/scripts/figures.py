"""
figures.py
==========
Genera las figuras del informe a partir de phreeqc_results.json.

Uso
---
    python figures.py

Produce
-------
    figures/figA_enfriamiento_mezcla.png
    figures/figB_pH_Be.png
"""

import json
import numpy as np
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import rcParams

# ── Estilo ──────────────────────────────────────────────────────────────────
rcParams["font.family"] = "DejaVu Serif"
rcParams["font.size"] = 9
rcParams["axes.linewidth"] = 0.8
rcParams["axes.spines.top"] = False
rcParams["axes.spines.right"] = False
rcParams["xtick.direction"] = "in"
rcParams["ytick.direction"] = "in"
rcParams["figure.dpi"] = 150

COLORS = {
    "Anhydrite": "#C0392B", "Calcite": "#2980B9",
    "Dolomite":  "#8E44AD", "Pyrite":  "#D4AC0D",
    "Quartz":    "#1ABC9C", "Bromellite": "#E67E22",
}

# ── Datos ────────────────────────────────────────────────────────────────────
results_path = Path("results") / "phreeqc_results.json"
with open(results_path) as f:
    data = json.load(f)

m2 = data["model2_cooling"]
m3 = data["model3_mixing"]
m4 = data["model4_pH"]

out_dir = Path("figures")
out_dir.mkdir(exist_ok=True)


# ── FIGURA A: Enfriamiento + pH + Mezcla ────────────────────────────────────
fig, axes = plt.subplots(1, 3, figsize=(13, 4.2))

# Panel a — SI vs T
ax = axes[0]
temps = [r["T"] for r in m2]
for mn, mk in [("Calcite","o"), ("Pyrite","s"), ("Anhydrite","^"), ("Quartz","D")]:
    vals = [r.get(mn) for r in m2]
    vals_clipped = [max(v, -15) if v is not None else None for v in vals]
    ax.plot(temps, vals_clipped, f"{mk}-", color=COLORS[mn], lw=1.6, ms=3.5,
            label=mn, markerfacecolor="white", markeredgewidth=1.2)
ax.axhline(0, color="k", lw=0.9, ls="--", alpha=0.6)
ax.fill_between(temps, 0, 1.5, color="#FADBD8", alpha=0.25)
ax.set_xlim(310, 140); ax.set_ylim(-15, 2)
ax.set_xlabel("Temperatura (°C)"); ax.set_ylabel("Índice de Saturación (SI)")
ax.set_title("(a) Enfriamiento 300→150 °C", loc="left")
ax.legend(fontsize=7.5, loc="lower right")
ax.annotate("Precipita", xy=(155, 0.3), fontsize=7.5, color="#C0392B", style="italic")

# Panel b — pH vs T
ax = axes[1]
pH_m2 = [r["pH"] for r in m2]
ax.plot(temps, pH_m2, "D-", color="#784212", lw=1.8, ms=3.5,
        markerfacecolor="white", markeredgewidth=1.2)
ax.axhspan(5.5, 6.5, alpha=0.15, color="#E67E22", label="Ventana transporte Be²⁺")
ax.set_xlim(310, 140); ax.set_ylim(4.5, 9)
ax.set_xlabel("Temperatura (°C)"); ax.set_ylabel("pH")
ax.set_title("(b) Evolución del pH", loc="left")
ax.legend(fontsize=7.5)

# Panel c — log[Be2+] y pH vs f_met
ax = axes[2]
m3p = [r for r in m3 if r["f_met"] < 1.0]
fmet = [r["f_met"] for r in m3p]
be2_log = [np.log10(r["Be2_mol"]) if r.get("Be2_mol") and r["Be2_mol"] > 0 else -30
           for r in m3p]
pH_m3 = [r["pH"] for r in m3p]

ax.plot(fmet, be2_log, "o-", color="#117A65", lw=1.8, ms=4,
        markerfacecolor="white", markeredgewidth=1.2, label="log m(Be²⁺)")
ax2b = ax.twinx()
ax2b.plot(fmet, pH_m3, "s--", color="#8E44AD", lw=1.4, ms=3.5,
          markerfacecolor="white", markeredgewidth=1.1, label="pH mezcla")
ax2b.set_ylabel("pH", color="#8E44AD")
ax2b.tick_params(axis="y", colors="#8E44AD")
ax2b.spines["right"].set_visible(True)
ax2b.spines["right"].set_color("#8E44AD")
ax.set_xlabel("Fracción agua meteórica (f_met)"); ax.set_ylabel("log m(Be²⁺)")
ax.set_title("(c) Mezcla: Be²⁺ y pH", loc="left")
ax.set_xticks([0, 0.2, 0.4, 0.6, 0.8])
ax.set_xticklabels(["0%", "20%", "40%", "60%", "80%"])
lns1, lbs1 = ax.get_legend_handles_labels()
lns2, lbs2 = ax2b.get_legend_handles_labels()
ax.legend(lns1 + lns2, lbs1 + lbs2, fontsize=7.5, loc="lower left")

plt.tight_layout(pad=1.2)
out_A = out_dir / "figA_enfriamiento_mezcla.png"
fig.savefig(out_A, dpi=150, bbox_inches="tight")
plt.close()
print(f"Guardada: {out_A}")


# ── FIGURA B: Especiación Be vs pH ───────────────────────────────────────────
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(9, 3.8))

pH_v   = [r["pH_set"] for r in m4]
log_be2 = [r["log_Be2"] for r in m4]
log_beo2= [r["log_BeO2"] for r in m4]
si_brom = [r["SI_Bromellite"] for r in m4]

ax1.plot(pH_v, log_be2,  "o-", color="#2471A3", lw=1.8, ms=4,
         label="log m(Be²⁺)", markerfacecolor="white", markeredgewidth=1.2)
ax1.plot(pH_v, log_beo2, "s-", color="#E74C3C", lw=1.8, ms=4,
         label="log m(BeO₂²⁻)", markerfacecolor="white", markeredgewidth=1.2)
ax1.axvspan(4.5, 6.0, alpha=0.12, color="orange", label="Ventana transporte Be²⁺")
ax1.axvline(5.5, color="gray", lw=0.8, ls=":", alpha=0.7)
ax1.text(5.55, -5, "pH\nMuzo", fontsize=7.5, color="gray")
ax1.set_xlabel("pH"); ax1.set_ylabel("log molalidad (mol/kgw)")
ax1.set_title("(a) Especiación acuosa del Be (T=200 °C)", loc="left")
ax1.set_ylim(-20, -2); ax1.set_xlim(3.8, 9.2)
ax1.legend(fontsize=7.5)

si_clip = [min(v, 80) for v in si_brom]
ax2.plot(pH_v, si_clip, "^-", color=COLORS["Bromellite"], lw=1.8, ms=4,
         label="SI Bromellite (proxy BeO)", markerfacecolor="white", markeredgewidth=1.2)
ax2.axhline(0, color="k", lw=0.9, ls="--", alpha=0.6)
ax2.fill_between(pH_v, 0, si_clip, color="#FAD7A0", alpha=0.35)
ax2.set_xlabel("pH"); ax2.set_ylabel("SI")
ax2.set_title("(b) Sobresaturación de Be (T=200 °C)", loc="left")
ax2.set_xlim(3.8, 9.2)
ax2.legend(fontsize=7.5)

plt.tight_layout(pad=1.2)
out_B = out_dir / "figB_pH_Be.png"
fig.savefig(out_B, dpi=150, bbox_inches="tight")
plt.close()
print(f"Guardada: {out_B}")

print("\nFiguras listas en ./figures/")
